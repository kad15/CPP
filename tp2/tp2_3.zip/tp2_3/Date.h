#ifndef DATE_H
#define DATE_H

#include <iostream>

using namespace std;

class Date
{
    int jour,mois,annee;

    public:
        Date();

        Date(int,int,int);

        int comparer(Date);

        void affiche();

        virtual ~Date();

};

#endif // DATE_H
