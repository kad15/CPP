#ifndef _PERSONNE_H
#define _PERSONNE_H

#include <iostream>

using std::string;

class Personne
{
    static int nb_pers;
    //compteur du nombre de personnes

    string nom;
    // le nom de la personne(objet string).

    string prenom;
    // le prenom de la personne (objet string).

    int id;
    //identifiant personne

    public:
    Personne();
    // construit une personne non initialisee (donc non valide).

    Personne(string nom, string prenom);
    // construit une personne valide.

    string getNom();
    //retourne le prenom de la personne

    void setNom(string nouveau_nom);
    // change le nom de la personne.

    string getPrenom();
    // retourne le prenom de la personne.

    void setPrenom(string nouveau_prenom);
    // change le prenom de la personne.

    void saisir();
    // saisie une personne

    void affiche();
    //affiche une personne

    ~Personne();
    // detruit cette personne et ses ressources allouees.

};   // fin de la classe Personne


#endif
