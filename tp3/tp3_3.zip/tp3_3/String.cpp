#include "String.h"

using namespace std;

namespace MaString
{
    std::ostream & operator<<(std::ostream & o,const string & s)
    {
        if(s.ch)	//pour eviter de faire cout de NULL
            o<<s.ch;
        return o;
    }
    std::istream & operator>>(std::istream & i,string & s)
    {
        i.getline(s.ch,MAX-1,'\n');
        return i;
    }

    string::~string()
    {
        std::cout<<"appel destructeur string"<<std::endl;
    }

    string::string(const char* chaine)
    {
        //std::cout<<"appel constructeur"<<std::endl;
        if (chaine==NULL)	//cas particulier du constructeur par defaut
        {
            lng=0;
            ch[0]='\0';
        }
        else
        {
            if(strlen(chaine)<MAX)
            {
                lng = strlen(chaine);
                strcpy(ch,chaine);
            }
            else
                std::cerr<<"erreur ds constructeur"<<std::endl;
        }
    }

    char& string::operator[](int i)
    {
        if(i<lng)
            return ch[i];
        else
            return ch[lng];
    }

    bool string::operator==(const char* ch)
    {
        return (!strcmp(this->ch,ch));
    }

    bool string::operator==(const string& s )
    {
        return (!strcmp(this->ch,s.ch));
    }

    bool operator==(const char* ch,const string& s)
    {
        return (!strcmp(ch,s.ch));
    }

    bool string::operator!=( const string& s)
    {
        return (strcmp(ch,s.ch));
    }
    bool string::operator<( const string& s)
    {
        return (strcmp(ch,s.ch)<0);
    }
    bool string::operator>( const string& s)
    {
        return (strcmp(ch,s.ch)>0);
    }
    bool string::operator<=( const string& s)
    {
       return (strcmp(ch,s.ch)<=0);
    }
    bool string::operator>=( const string& s)
    {
        return (strcmp(ch,s.ch)>=0);
    }
    string & string::operator+=(const string& s)
    {
        if(lng+s.lng<MAX)
        {
            lng=lng+s.lng;
            strcat(ch,s.ch);
        }
        else
            std::cerr<<"erreur dans operateur+="<<std::endl;

        return (*this);
    }

    string operator+(const string & s1,const string & s2)
    {
        string temp;

        if(s1.lng + s2.lng<MAX)
        {
            temp.lng = s1.lng + s2.lng;
            strcpy(temp.ch,s1.ch);
            strcat(temp.ch,s2.ch);
        }
        else
            std::cerr<<"erreur dans operateur+"<<std::endl;

        return temp;
    }

    void getline(std::istream& i,string& s)
    {
        i.getline(s.ch,MAX-1,'\n');
        s.ch[strlen(s.ch)]='\0';    //pour supprimer le passage a la ligne
    }
}
