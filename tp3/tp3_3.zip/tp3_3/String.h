#ifndef STRING_H    //attention a ne pas utiliser _STRING_H_
#define STRING_H    //sinon le compilateur refusera l inclusion de <cstring>

#include <iostream>
#include <cstring>

#define MAX 1000

namespace MaString
{
    class string
    {
        int lng;
        char ch[MAX];

        friend std::ostream & operator<<(std::ostream & o,const string & s);
        friend std::istream & operator>>(std::istream & i,string & s);

        public:
            //constructeur
            string(const char *st="NULL");

             //destructeur
            virtual ~string();

            // Surcharge de [], permettant d extraire un caractere d une string :
            char& operator[](int i);

            // Surcharge des operateurs relationnels par fonctions amies independantes
            friend bool operator == (const char * , const string &);
            //surcharge de getline
            friend void getline(std::istream& , string&);

            // Surcharge par fonctions membres
            bool operator == (const string& );
            bool operator == (const char* );

            bool operator != (const string & );
            bool operator < (const string & );
            bool operator > (const string & );
            bool operator <= (const string & );
            bool operator >= (const string & );

            // Surcharge de += ajoutant en fin de la chaine appelante la chaine s :
            string & operator+=(const string & s);

            // Surcharge de + permettant la concatenation de deux chaines s1 et s2
            // sans modifier ces dernieres :
            friend string operator + ( const string & s1,const string & s2) ;
    };
}
#endif
