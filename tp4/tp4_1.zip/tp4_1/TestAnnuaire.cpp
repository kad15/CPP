#include "Annuaire.h"

int main()
{
    Annuaire a;
    a.gerer();

    return 0;
}
